function mdl = apply_model_configuration(mdl,ode)
%APPLY_MODEL_CONFIGURATION Resolve initial states and model-specific constants.
% ode.y0 overrides the legacy solver vector mdl.y0. Missing overrides retain
% the source defaults, including the cumulative-discharge bookkeeping state.
    if nargin<2, ode=struct(); end
    if ~isfield(mdl,'initial_state_defaults')
        mdl.initial_state_defaults=mdl.y0(:);
    end
    if isfield(ode,'y0') && ~isempty(ode.y0)
        initial=ode.y0;
        if ~isnumeric(initial) || ~isreal(initial) || ~isvector(initial) ...
                || numel(initial)~=numel(mdl.y0) || any(~isfinite(initial)) || any(initial<0)
            error('apply_model_configuration:InitialStates', ...
                'Initial states must contain %d finite nonnegative values.',numel(mdl.y0));
        end
        physical=initial(1:end-1);
        if any(physical<=0 | physical>100)
            error('apply_model_configuration:InitialStorageRange', ...
                'Editable initial storage values must be greater than zero and at most 100 mm.');
        end
        mdl.y0=double(initial(:));
    end
    if ismember(mdl.model,1:7) || isfield(mdl,'configuration_definition')
        mdl.config=resolve_model_config(mdl);
    end
end
