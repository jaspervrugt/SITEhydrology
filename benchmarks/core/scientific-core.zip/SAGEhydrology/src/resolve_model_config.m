function config = resolve_model_config(mdl)
%RESOLVE_MODEL_CONFIG Merge source defaults and validate named overrides.
    persistent catalogs
    if isempty(catalogs), catalogs=cell(1,7); end
    id=double(mdl.model);
    if ismember(id,1:7)
        if isempty(catalogs{id})
            definition=model_configuration(mdl);catalogs{id}=definition.values;
        end
        values=catalogs{id};
    else
        definition=model_configuration(mdl);values=definition.values;
    end
    config=struct();
    supplied=struct();
    if isfield(mdl,'config') && ~isempty(mdl.config), supplied=mdl.config; end
    if ~isstruct(supplied) || ~isscalar(supplied)
        error('resolve_model_config:Structure','mdl.config must be a scalar structure.');
    end
    allowed=values.Symbol;
    unknown=setdiff(fieldnames(supplied),allowed);
    if ~isempty(unknown)
        error('resolve_model_config:Unknown','Unsupported model configuration: %s.',strjoin(unknown,', '));
    end
    for i=1:height(values)
        key=allowed{i};value=values.Default(i);
        if isfield(supplied,key), value=supplied.(key); end
        if ~(isnumeric(value) && isreal(value) && isscalar(value) && isfinite(value))
            error('resolve_model_config:Value','%s must be a finite real scalar.',key);
        end
        if ~values.Editable(i) && value~=values.Default(i)
            error('resolve_model_config:Fixed','%s is fixed by the current model formulation.',key);
        end
        if value<=values.Lower(i)
            error('resolve_model_config:Bounds','%s must be greater than %g.',key,values.Lower(i));
        end
        config.(key)=double(value);
    end
end
