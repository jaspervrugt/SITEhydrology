function meta = model_configuration(mdl)
%MODEL_CONFIGURATION State and additional-value definitions from model source.
% Defaults preserve the current MATLAB formulations. Configuration is fixed
% during parameter differentiation; it is not another calibrated parameter.
    id = double(mdl.model);
    names = {}; symbols = {}; capacity = {};
    switch id
        case 1
            names = {'Snow water equivalent','Unsaturated soil storage', ...
                'Slow reservoir storage','Fast reservoir 1 storage', ...
                'Fast reservoir 2 storage','Fast reservoir 3 storage'};
            symbols = {'S_swe','S_u','S_s','S_f1','S_f2','S_f3'};
            capacity = {'','th(1)','','','',''};
        case 2
            names = {'Snow water equivalent','Interception storage', ...
                'Unsaturated soil storage','Fast reservoir storage','Slow reservoir storage'};
            symbols = {'S_swe','S_i','S_u','S_f','S_s'};
            capacity = {'','th(1)','th(2)','',''};
        case 3
            names = {'Snow water equivalent','Upper tension-water storage', ...
                'Upper free-water storage','Lower tension-water storage', ...
                'Lower primary free-water storage','Lower supplemental free-water storage', ...
                'Routing reservoir 1 storage','Routing reservoir 2 storage','Routing reservoir 3 storage'};
            symbols = {'S_swe','S_ut','S_uf','S_lt','S_lfp','S_lfs','S_r1','S_r2','S_r3'};
            capacity = {'','th(2)','th(1)','th(5)','th(3)','th(4)','','',''};
        case 4
            names = {'Snow water equivalent','Tension-water storage','Free-water storage', ...
                'Interflow reservoir storage','Baseflow reservoir storage', ...
                'Routing reservoir 1 storage','Routing reservoir 2 storage','Routing reservoir 3 storage'};
            symbols = {'S_swe','W','S','S_i','S_g','S_r1','S_r2','S_r3'};
            capacity = {'','th(5)*th(8)','(1-th(5))*th(8)','','','','',''};
        case 5
            names = {'Snow water equivalent','Production store','Routing store'};
            symbols = {'S_swe','S_p','S_r'}; capacity = {'','th(1)','th(3)'};
            for j=1:mdl.n1
                names{end+1}=sprintf('Unit hydrograph 1, cascade store %d',j);
                symbols{end+1}=sprintf('H_1,%d',j); capacity{end+1}='';
            end
            for j=1:mdl.n2
                names{end+1}=sprintf('Unit hydrograph 2, cascade store %d',j);
                symbols{end+1}=sprintf('H_2,%d',j); capacity{end+1}='';
            end
        case 6
            names = {'Snow water equivalent','Soil water storage','Upper-zone storage','Lower-zone storage'};
            symbols = {'S_swe','S_m','S_uz','S_lz'}; capacity = {'','th(1)','',''};
        case 7
            names = {'Snow water equivalent','Soil water storage','Groundwater storage'};
            symbols = {'S_swe','S','G'}; capacity = {'','th(1)',''};
            for j=1:numel(mdl.giuh_ordnts)
                names{end+1}=sprintf('GIUH routing store %d',j);
                symbols{end+1}=sprintf('H_%d',j); capacity{end+1}='';
            end
            nashCount=numel(mdl.y0)-4-numel(mdl.giuh_ordnts);
            for j=1:nashCount
                names{end+1}=sprintf('Nash routing store %d',j);
                symbols{end+1}=sprintf('N_%d',j); capacity{end+1}='';
            end
        otherwise
            for j=1:numel(mdl.y0)-1
                if isfield(mdl,'state_name') && numel(mdl.state_name)>=j
                    names{j}=char(strrep(string(mdl.state_name(j)),'_',' '));
                    symbols{j}=char(string(mdl.state_name(j)));
                else
                    names{j}=sprintf('Model state %d',j); symbols{j}=sprintf('S_%d',j);
                end
                capacity{j}='';
            end
    end
    % The last solver state accumulates discharge; expose but do not edit it.
    names{end+1}='Accumulated discharge (solver bookkeeping)';
    symbols{end+1}='Q_cum'; capacity{end+1}='';
    n=numel(mdl.y0);
    if numel(names)~=n
        error('model_configuration:StateCount','State definitions do not match model %d.',id);
    end
    units=repmat({'mm'},n,1);
    if isfield(mdl,'state_units') && numel(mdl.state_units)>=n
        units=cellstr(string(mdl.state_units(1:n))'); units=units(:);
    end
    meta.states=table((1:n)',symbols(:),names(:),units,mdl.y0(:), ...
        [true(n-1,1);false],capacity(:),'VariableNames', ...
        {'Index','Symbol','Description','Unit','Default','Editable','Capacity'});
    meta.values=table(cell(0,1),cell(0,1),cell(0,1),zeros(0,1),false(0,1), ...
        zeros(0,1),cell(0,1),'VariableNames', ...
        {'Name','Symbol','Unit','Default','Editable','Lower','Reference'});
    if ~ismember(id,1:7)
        if isfield(mdl,'configuration_definition'),meta.values=mdl.configuration_definition;end
        return
    end
    source='';
    if id~=6
        add('T_sm','Snow/rain smoothing width',[char(176) 'C'],1,true,0,source);
        add('eps_m','Smooth minimum/maximum width','mixed units',1e-6,true,0,source);
    end
    if ismember(id,[3 5]), add('eps_s','Storage regularization width','mm',1e-12,true,0,source); end
    if id==4, add('eps_r','Regime-transition regularization','-',1e-12,true,0,source); end
    if id==6
        add('eps_s','Storage/flux smoothing width','mm',1e-3,true,0,source);
        add('eps_t','Temperature smoothing width',[char(176) 'C'],0.1,true,0,source);
        add('eps_x','Storage/denominator regularization','mm',1e-12,true,0,source);
    end
    if ismember(id,[3 4 6 7])
        add('eps','Logistic storage-transition offset','-',5,id==3,-Inf,source);
    end
    add('rho','Relative storage-transition smoothing','-',0.01,ismember(id,[1 3]),0,source);
    if id==1, add('eps_c','Normalized soil-storage clamp width','-',1e-6,false,0,source); end
    if id==2
        add('a_S','Percolation exponential-shape coefficient','-',1e-6,true,0,'Schoups et al. (2010)');
        add('a_I','Interception infiltration-shape coefficient','-',50,false,0,'Schoups et al. (2010)');
        add('a_P','Effective-precipitation shape coefficient','-',-50,false,-Inf,'Schoups et al. (2010)');
    end
    if id==5
        add('kappa','Percolation shape constant','-',4/9,true,-eps,'Perrin et al. (2003)');
        add('bg','Groundwater exchange exponent','-',3.5,true,0,'Mathevet (2005)');
        add('bR','Routing outflow exponent','-',5,true,1,'Perrin et al. (2003)');
        add('mts','Model time-step factor','sample',1,false,0,'');
    end
    if id==7
        add('K','Number of Nash routing stores','-',3,true,0,'>= 1');
        % Vector default is resolved explicitly by resolve_model_config.
        add('giuh_ordnts','GIUH unit-hydrograph ordinates','-',NaN,true,-Inf, ...
            'Finite nonnegative vector; ordinates must sum to one.');
        add('dT','Schaake forcing time-step factor','d',1,false,0,'');
        add('eps_r','Flow-regime regularization','-',1e-12,false,0,source);
    end
    function add(field,description,unit,value,editable,lower,reference)
        meta.values(end+1,:)={description,field,unit,value,editable,lower,reference};
    end
end
