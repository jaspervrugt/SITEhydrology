/*
 * hmodel.hpp
 *
 * Public native interface for the HMODEL rainfall-runoff model. The
 * interface contains no MATLAB types so it can be used by both the standalone
 * crr_hmodel gateway and the unified crr_model_mex dispatcher.
 *
 * Written by Jasper A. Vrugt.
 * Native-core interface introduced for SAGEhydrology, 2026.
 */

#pragma once
#include <cstddef>

namespace sage_hmodel {
struct Params {
    double I_max;
    double Su_max;
    double Q_max;
    double a_E;
    double a_F;
    double a_S;
    double r_f;
    double r_s;
    double T_tr;
    double f_dd;
    double T_sm;
    double eps_m;
    double rho;
};

struct Options {
    double InitStep, MaxStep, MinStep, RelTol, AbsTol, Order;
    int maxiter;
};

struct Forcing {
    const double* P = nullptr;
    const double* Ep = nullptr;
    const double* T = nullptr;
    std::size_t n = 0;
};

struct OutputView {
    double* Z = nullptr;
    double* q = nullptr;
    double* J = nullptr;
    std::size_t zrows = 0, zcols = 0, nq = 0, nj = 0;
    double* swe = nullptr;
    double* Jswe = nullptr;
    double* sm = nullptr;
    double* Jsm = nullptr;
};

bool run_into(int ns,
              const double* z0,
              std::size_t nz0,
              const Forcing&,
              const Params&,
              const Options&,
              bool mem,
              int ipr,
              bool needJ,
              const OutputView&);
} // namespace sage_hmodel
